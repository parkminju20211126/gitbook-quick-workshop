# Customer Feedback Summary — Rewards Program
**Compiled by:** Seoyeon Lee, Customer Experience
**Period:** July 2025 — December 2025
**Sources:** Support tickets, app store reviews, social media mentions, NPS surveys

## NPS Scores by Segment

| Segment | Q2 2025 | Q3 2025 | Q4 2025 | Trend |
|---------|---------|---------|---------|-------|
| 18-25 | 32 | 28 | 24 | ↓ Declining |
| 26-35 | 41 | 35 | 31 | ↓ Declining |
| 36-45 | 48 | 47 | 46 | → Stable |
| 46-55 | 52 | 51 | 53 | → Stable |
| 55+ | 58 | 59 | 57 | → Stable |
| **Overall** | **44** | **41** | **38** | **↓ Declining** |

## Rewards-Related Support Ticket Volume

| Category | Q2 2025 | Q3 2025 | Q4 2025 |
|----------|---------|---------|---------|
| "How do I check my tier?" | 1,247 | 1,589 | 1,834 |
| "I can't see my points" | 892 | 1,103 | 1,267 |
| "How do I redeem?" | 2,134 | 2,456 | 2,891 |
| "Why did my points expire?" | 567 | 734 | 1,102 |
| "Tier downgrade complaint" | 312 | 445 | 623 |
| **Total Rewards Tickets** | **5,152** | **6,327** | **7,717** |

Rewards-related tickets grew 50% from Q2 to Q4. They now represent 34% of total support volume (up from 22%) — a meaningful shift in ticket mix.

## Verbatim Customer Feedback

### App Store Reviews (1-2 star reviews mentioning rewards)
- "Great card but the rewards program is impossible to understand. I've had this card for 2 years and I still don't know what tier I'm in." ★★☆☆☆
- "Points expired without any warning. Lost $200 worth of points overnight. Switching to Chase." ★☆☆☆☆
- "The app shows me my points but not what I can do with them. Why is this so hard?" ★★☆☆☆
- "Got downgraded from Gold to Silver because I didn't spend enough one month. ONE month! Ridiculous." ★☆☆☆☆

### Positive Feedback (for balance)
- "Once I figured out how to use it, the value was actually great. Got a free flight to Chicago." ★★★★★
- "Customer service helped me understand my rewards. Wish the app was as clear as they were." ★★★★☆
- "The cashback rate is actually better than most competitors. They just need to make it easier to use." ★★★★☆

### Social Media Highlights
- Twitter/X thread with 2.3K likes: "day 847 of not understanding my [redacted] rewards tier" (August 2025)
- Reddit post on r/PersonalFinance: "Am I the only one, or is [redacted]'s rewards program intentionally confusing?" — 156 upvotes, top comment: "Not just you. I switched to Chase last month." (September 2025)

## Churn Analysis (Rewards-Related)

| Metric | Value |
|--------|-------|
| Customers citing rewards as a reason for leaving | 23% of total churn |
| Average tenure of rewards-driven churners | 2.3 years |
| Average monthly spend before churning | $1,847 |
| Estimated annual revenue loss from rewards-related churn | $4.4M |
| Cost to acquire replacement customer | $340 (vs. $45/year retention cost) |

## Recommendation
The data strongly supports the rewards redesign initiative. Customer dissatisfaction is accelerating, not stabilizing. Every quarter of delay costs approximately $1.1M in preventable churn. The redesign must prioritize simplicity and transparency above all else. Customers are not asking for more rewards — they are asking to understand the ones they have.
