# Compliance Review — Rewards Program Redesign
**Date:** November 14, 2025
**Attendees:** Jisu Han (Chief Compliance Officer), Sooah Jung (VP Product), Daesung Kim (CTO), Minho Ahn (Legal Counsel)

## Purpose
Review the regulatory and compliance implications of the proposed 3-tier rewards redesign before development begins.

## Issues Identified

### Issue 1: Tier Transition Notice (Resolved)
**Regulation:** Consumer financial protection guidance on fee disclosures
**Concern:** Changing a customer's tier constitutes a material change to their account terms. Customers must receive written notice within 30 days prior to the change taking effect.
**Resolution:** Sooah Jung confirmed the communication plan will provide 45 days' advance notice, including email + in-app notifications + physical mail for customers without registered email addresses. Jisu Han approved this approach.
**Status:** ✅ Resolved

### Issue 2: Point Conversion Fairness (Under Review)
**Regulation:** Consumer protection framework — fair treatment of customers
**Concern:** When converting points from the existing 5-tier system to the new 3-tier system, no customer may receive lower value than what they currently hold. The proposed conversion formula requires legal review to confirm no customer is disadvantaged.
**Details:** Minho Ahn identified an edge case where customers currently in the "Silver" tier (which will be sunset) may lose access to Silver-only redemption options before they have a chance to use their accrued points. The proposed 90-day grace period may not be sufficient for customers with large point balances.
**Required Action:** Legal must model the worst-case scenario for Silver-tier customers holding more than 50,000 points and propose a fair conversion approach.
**Status:** ⏳ Under legal review — target completion December 15, 2025

### Additional Notes
- Jisu Han requested that all customer communications be reviewed by Compliance prior to distribution.
- Daesung Kim confirmed that the LoyaltyCore platform can support a parallel-run period during which both the existing and new tier structures operate simultaneously.
- Minho Ahn recommended documenting the business rationale for the redesign in anticipation of future regulatory inquiries.

## Next Steps
- [ ] Minho Ahn: Complete legal analysis of point conversion by December 15
- [ ] Sooah Jung: Submit draft customer communications to Compliance by December 1
- [ ] Daesung Kim: Confirm technical feasibility of parallel-run with LoyaltyCore by November 30

---
*This review does not constitute legal advice. Formal legal opinion to be provided separately by Minho Ahn.*
