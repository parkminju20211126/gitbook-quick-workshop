# Loyalty Platform Vendor Evaluation Summary

This evaluation compares two loyalty platform vendors for the rewards redesign initiative.

**LoyaltyCore (Incumbent):** Our current provider since 2019, offering a $2.1M three-year cost and 5-month timeline with minimal integration risk. However, it has significant limitations, particularly in analytics capabilities, requiring supplementary reporting tools.

**RewardStack (New Vendor):** A startup alternative at $2.8M with an 8-month implementation timeline. The recommendation favors RewardStack for its "native support for tier + points + hybrid models" and its "built-in real-time dashboards, A/B testing of reward offers, and predictive churn modeling."

**Key Argument:** The evaluator argues that RewardStack's comprehensive analytics suite eliminates the need to maintain separate reporting infrastructure, offsetting the higher cost through approximately $400K in annual operational savings.

**Next Steps:** A leadership presentation is scheduled for October 28, targeting procurement kickoff by November 15 upon approval. The evaluator emphasizes that data residency compliance with applicable regulations must be verified before proceeding.
