# Customer Research Summary — Rewards Program Perception Study
**Author:** Jiyoung Park, Analytics Lead
**Date:** September 8, 2025
**Methodology:** Online survey (n=2,847) + 12 focus groups across New York, San Francisco, and Chicago

## Executive Summary
Customers overwhelmingly want simplicity. The current Rewards Program is perceived as competitive on benefit value but poor on ease of use. The biggest opportunity is not adding more rewards, but making existing rewards easier to understand and redeem.

## Key Findings

### Awareness and Understanding
- 62% of customers described the current tier structure as "confusing" or "very confusing"
- Only 23% could accurately identify their current tier
- 78% did not know their current point balance without checking the app
- Customers who understand the program spend 2.1x more on their cards

### Earning and Redemption Behavior
- Average time from earning to redemption: 14.3 months (industry average: 8.2 months)
- 34% of earned points expire unused (approximately $4.2M in unrealized engagement)
- Top redemption categories: Travel (41%), Cashback (33%), Gift Cards (18%), Merchandise (8%)
- Customers who redeem points within 90 days show 67% higher 12-month retention

### Competitive Perception
- Our rewards value rating: 3.8/5 (industry average 3.5/5)
- Our rewards ease-of-use rating: 2.4/5 (industry average 3.1/5)
- Most-mentioned competitors: Ally Bank (on simplicity), Chase (on value)

### Focus Group Quotes
> "I know I have points, but I have no idea what they're worth. Chase is simple — one point equals one cent."
> — Focus group participant, New York, age 28

> "I didn't even know I'd been upgraded to Gold. What does that actually do for me?"
> — Focus group participant, San Francisco, age 34

> "I'd rather have a few options I actually understand than 50 menu items I'll never use."
> — Focus group participant, Chicago, age 31

## Recommendations
1. Simplify to three or fewer tiers, each with clearly differentiated benefits
2. Implement real-time point balance visibility (push notifications)
3. Introduce a "1 point = 1 cent" equivalent for cashback redemptions
4. Create a 90-day redemption nudge to reduce point expiration

## Appendix
Full survey data and focus group transcripts are available on the shared research drive.
