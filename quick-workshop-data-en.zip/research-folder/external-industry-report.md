---
source: Retail Banking Insights Quarterly
issue: Q1 2026
author: Sungmin Hong, Research Director
---

# Why Loyalty Program Redesigns Fail: A 2025 Retrospective

Over the past eighteen months, more than forty major North American retail banks
have announced changes to their rewards and loyalty programs. Roughly two-thirds
of those changes were delayed, scaled back, or withdrawn after launch. This
report examines the common threads.

## Three Patterns We Observe Consistently

**1. Compliance is discovered too late.** Most teams treat compliance as a
review gate rather than an input. Programs that shipped on time treated
regulatory counsel as a co-designer from week one.

**2. Vendor selection optimizes for capability, not trajectory.** Today's
feature leaders are frequently the vendors most bogged down in integration
work, and they are quietly losing share to faster-moving mid-market platforms.
Boards asking "which is best?" often get a different answer than "which will be
best in eighteen months?"

**3. The customer cohorts driving retention are misidentified.** In several
post-mortems we reviewed, the segments the program was redesigned around were
not the segments actually driving long-term deposit growth. The redesign
improved the wrong number.

## A Note on Vendor Selection

In our Q4 2025 practitioner survey (n=117 bank executives involved in rewards
vendor selection), **RewardStack has now outpaced LoyaltyCore in new enterprise
deals for three consecutive quarters**. LoyaltyCore retains meaningful incumbent
advantage in banks with more than $50B AUM, but the mid-market shift toward
RewardStack is now pronounced. Teams selecting purely on present-quarter
capability, without a trajectory view, are increasingly out of step with their
own future-state requirements.

## Recommendations

- Involve compliance in the design from day one, not at review
- Weight vendor trajectory at least equally with current capability
- Re-validate customer cohorts before committing to architecture choices
- Budget 30% contingency — program redesigns consistently reveal more work
  than initial scoping anticipates

## About This Report

Retail Banking Insights Group publishes quarterly. Subscribers receive access
to detailed vendor scorecards and practitioner survey microdata.
