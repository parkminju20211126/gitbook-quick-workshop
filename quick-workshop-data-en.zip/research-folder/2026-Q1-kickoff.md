# Summary: Q1 2026 Rewards Program Redesign

## Current Status
The rewards program redesign initiative is in flight but facing a significant compliance delay. The LoyaltyCore contract was successfully renewed in December, and the three-tier structure (Essentials → Preferred → Premium) has been finalized. However, **the legal analysis on point conversion fairness remains unresolved**, blocking the May 2026 launch.

## Blocker
Per meeting notes: "We will not approve go-live until this issue is resolved." Specifically, handling of Silver-tier customers holding more than 50,000 points requires legal sign-off before customer migration can proceed. This analysis was due December 15 but is still outstanding; the new target is January 31.

## Budget and Resources
The team has allocated $350K to Q1 work — $200K for analytics infrastructure and $150K for LoyaltyCore development. In a notable decision, leadership chose Metabase (open-source) over a commercial analytics platform, saving approximately $120K.

## Rollout Strategy
The team will launch in phases by customer tier: Premium (highest engagement) first, followed by Preferred, then Essentials. A 30-day parallel run will keep both legacy and new systems operating during the transition.

## Key Risks
Beyond the compliance blocker, slow technical response from Delta Airlines could delay co-brand integration, and Customer Service must be prepared for potential customer backlash over the tier discontinuation regardless of any fairness measures taken during conversion.
