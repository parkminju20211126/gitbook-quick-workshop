# Product Review — Rewards Program Redesign
**Date:** August 12, 2025
**Attendees:** Sooah Jung (VP Product), Dohyun Kim (Partnerships Lead), Jiyoung Park (Analytics Lead), Jae-Hyun Oh (CFO), Seoyeon Lee (Customer Experience)

## Background
Customer churn in the 18–35 segment is up 14% quarter-over-quarter. Exit surveys consistently cite "confusing rewards structure" as a top-three reason for leaving. Our current five-tier system was launched in 2021 and has not been refreshed since.

## Discussion

**Sooah Jung** opened by framing this as a retention initiative, not a growth initiative. The goal is to stop the bleed among our most valuable customers before we invest in acquisition.

**Jiyoung Park** presented the analytics deep dive:
- Only 23% of customers understand how to maximize their rewards
- 62% describe the current tier structure as confusing (up from 41% year-over-year)
- Customers who actively use rewards have 3.2x higher lifetime value
- "Gold" and "Platinum" tiers show near-identical usage patterns, suggesting they should be merged

**Dohyun Kim** raised concerns about partnership impacts. Our co-branded card with Delta Airlines relies on the current tier structure. Any changes require 90-day notice under the partnership agreement.

**Jae-Hyun Oh** flagged budget constraints. Q4 budget is fully allocated. Any new platform investment would have to come from Q1 2026 budget unless we can build a case for pulling it forward.

## Options Considered

1. **Simplify to 3 tiers** — Merge Gold/Platinum, keep the entry tier, add one premium tier. Lowest cost, fastest to implement.
2. **Points-based system** — Abandon tiers entirely, replace with a simple points-accrual model. Higher upfront cost but better long-term flexibility.
3. **Hybrid approach** — Keep tiers for status but add a points layer for redemption. Most complex but preserves partnerships.

## Action Items
- [ ] Jiyoung Park: Model revenue impact of each option by Sep 15
- [ ] Dohyun Kim: Review Delta contract for redesign flexibility
- [ ] Sooah Jung: Draft customer communication plan for each scenario
- [ ] Jae-Hyun Oh: Identify Q1 budget reallocation options

## Decision
**Deferred.** Reconvene after Jiyoung Park's modeling is complete. Target decision: October board meeting.

---
*Notes taken by Seoyeon Lee. Shared with attendees and Eunji Kang (CEO).*
